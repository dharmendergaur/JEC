from CRABClient.UserUtilities import config
config = config()

config.General.transferLogs = True
config.General.transferOutputs = True

config.JobType.psetName = 'nano.py'
config.General.requestName = 'jetMET24I'
config.Data.outputDatasetTag = 'jetMET24I'

config.JobType.pluginName = 'Analysis'
config.JobType.outputFiles = ['nano.root']
config.JobType.maxMemoryMB = 2500

config.Data.inputDataset = '/JetMET0/Run2024I-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.useParent = True
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob =1 

#config.Data.runRange = "386924"

config.Data.allowNonValidInputDataset = True
config.Data.outLFNDirBase = '/store/group/dpg_trigger/comm_trigger/L1Trigger/lroberts/JECs2025/JETMET24I/miniaod/baseline'

config.Data.lumiMask = 'https://cms-service-dqmdc.web.cern.ch/CAF/certification/Collisions24/Cert_Collisions2024_378981_386951_Golden.json'

config.Site.storageSite = 'T2_CH_CERN'

